import { Component, Input, Output, EventEmitter, OnInit, SimpleChanges } from '@angular/core';
import { FeatureDataService } from '../services/feature-data.service';

@Component({
  selector: 'app-duplicate-stories-modal',
  templateUrl: './duplicate-stories-modal.component.html',
  styleUrls: ['./duplicate-stories-modal.component.css'],
})
export class DuplicateStoriesModalComponent {
  @Input() showModal!: boolean;
  @Input() duplicateStoriesData: string[] = [];
  @Input() newStoriesData: string[] = [];

  selectedDuplicateStories: string[] = [];
 selectedNewStories: string[] = [];

  @Output() closeModalEvent = new EventEmitter<void>();
  //duplicateStoriesData: string[] | undefined;

  constructor(private featureDataService: FeatureDataService) {}

  ngOnInit(): void {
    //const dataDup = this.duplicateStoriesData;
    //const dataDup =  this.duplicateStoriesData;
   // dataDup.map()
   
  //  this.duplicateStoriesData = this.duplicateStoriesData;
    
    //console.log("this.duplicateStoriesData", this.duplicateStoriesData);
   // this.newStoriesData = this.newStoriesData;
    //console.log("this.newStoriesData", this.newStoriesData);
    // Ensure the selected stories arrays are initialized
    if (!this.selectedDuplicateStories.length) {
      this.selectedDuplicateStories = this.featureDataService.getSelectedDuplicateStories();
    }
    if (!this.selectedNewStories.length) {
      this.selectedNewStories = this.featureDataService.getSelectedNewStories();;
    }
    console.log(this.selectedDuplicateStories);
    console.log(this.selectedNewStories);

  }
  ngOnChanges(changes:SimpleChanges){
    console.log(changes)
  }

  confirmSelection() {
    //console.log('Selected Duplicate Stories:', this.selectedDuplicateStories);
    //console.log('Selected New Stories:', this.selectedNewStories);

    this.featureDataService.setSelectedNewStories(this.selectedNewStories);
    this.featureDataService.setSelectedDuplicateStories(this.selectedDuplicateStories);
    this.closeModalEvent.emit();
    this.showModal = false;
    }

  closeModal() {
    this.selectedDuplicateStories = [];
    this.selectedNewStories = [];
    this.closeModalEvent.emit();
    this.showModal = false;
    this.featureDataService.setSelectedNewStories([]);
    this.featureDataService.setSelectedDuplicateStories([]);
  }

  toggleDuplicateStorySelection(story: string) {
    const index = this.selectedDuplicateStories.indexOf(story);
    if (index > -1) {
      this.selectedDuplicateStories.splice(index, 1);
    } else {
      this.selectedDuplicateStories.push(story);
    }
  }

  toggleNewStorySelection(story: string) {
    const index = this.selectedNewStories.indexOf(story);
    if (index > -1) {
      this.selectedNewStories.splice(index, 1);
    } else {
      this.selectedNewStories.push(story);
    }
  }
}