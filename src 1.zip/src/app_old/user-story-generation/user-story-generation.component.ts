import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FeatureService } from '../services/feature.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FeatureDataService } from '../services/feature-data.service';
import { timeout } from 'rxjs/operators';

@Component({
  selector: 'app-user-story-generation',
  templateUrl: './user-story-generation.component.html',
  styleUrls: ['./user-story-generation.component.css'],
})
export class UserStoryGenerationComponent {
  errorMessage: string | null = null;
  userstorygenerated: string = '';
  description: string = '';
  summary: string = '';
  stepsIdentification: string = '';
  isLoading: boolean = false; // Property to control the loader
  userstorypayload: string = '';
  userid: any;
  featureID: any;
  duplicateuserstory: any[]=[]; // Changed to string array
  newuserstory: any[]=[]; // Changed to string array
  showModal: boolean = false; // Control modal visibility
  // Define these properties to track selected stories
  selectedDuplicateStories: string[] = [];
  selectedNewStories: string[] = [];
  duplicateuserstoryData: any;
  newuserstoryData: any;

  constructor(
    private router: Router,
    private featureService: FeatureService,
    private featureDataService: FeatureDataService
  ) { }

  ngOnInit(): void {
    this.description = this.featureDataService.getDescription();
    this.summary = this.featureDataService.getSummary();
    this.featureID = this.featureDataService.getFeatureId();
    this.stepsIdentification = this.featureDataService.getStepsIdentification();
    this.userstorygenerated = this.featureDataService.getUserStoryGenerated();
  }

  // generateuserstory(): void {
  //   this.isLoading = true; // Show loader
  //   this.userid = null;
  //   this.userstorypayload = `Summary:${this.summary},Description:${this.description},tasks:${this.stepsIdentification},userid:${this.userid}`;
  //   // Hardcoded response
  //   const response = [
  //     'User Story 1:\nSummary: Implement File Upload Functionality\nDescription: As a user, I want to upload a document in various formats including PDF, Word, and plain text to the tool for summarization.\nTechnical Details: Implementation of a document upload feature that supports various formats including PDF, Word, and plain text. The user interface should be simple and intuitive.\nAcceptance Criteria: Users can successfully upload documents in various formats. The uploaded document is correctly processed by the tool.\nSequence of execution and dependency: This user story is the first step and has no dependencies.\n------------------------------------------------------------------------------------\n\nUser Story 2:\nSummary: Implement AI Model for Text Summarization\nDescription: As a developer, I need to develop and train the AI model for text summarization to ensure high-level accuracy.\nTechnical Details: Development and training of an AI model capable of summarizing text from various document formats. The AI model should achieve at least 90% user satisfaction based on feedback.\nAcceptance Criteria: The trained AI model accurately summarizes text from various document formats and achieves at least 90% user satisfaction based on feedback.\nSequence of execution and dependency: This user story depends on User Story 1. The AI model will be tested once the document upload functionality is in place.\n------------------------------------------------------------------------------------\n\nUser Story 3:\nSummary: Implement Summary Generation Feature\nDescription: As a user, I want the tool to generate a summary that accurately reflects the key points of the original document.\nTechnical Details: Implementation of a summarization output feature that generates a summary based on the input document. The summary should preserve the context and meaning of the original text.\nAcceptance Criteria: The tool generates a summary that accurately reflects the key points of the original document.\nSequence of execution and dependency: This user story depends on User Story 2. The summary generation feature will use the AI model developed in User Story 2.\n------------------------------------------------------------------------------------',
  //     '{"Duplicated Stories": [], "New Stories": ["User Story 1: Implement File Upload Functionality", "User Story 2: Implement AI Model for Text Summarization", "User Story 3: Implement Summary Generation Feature"]}'
  //   ];

  //   this.isLoading = false; // Hide loader
  //   if (response && Array.isArray(response)) {
  //     // Print all user stories
  //     this.userstorygenerated = response[0];
  //     console.log("User Stories:", this.userstorygenerated);
  //     // Parse the object at index 1
  //     const storiesObject = JSON.parse(response[1]);
  //     if (storiesObject) {
  //       this.duplicateuserstory = storiesObject["Duplicated Stories"];
  //       this.newuserstory = storiesObject["New Stories"];
  //       console.log("Duplicated Stories:", this.duplicateuserstory);
  //       console.log("New Stories:", this.newuserstory);
  //     } else {
  //       console.error('The structure of the second item in the array is not as expected:', storiesObject);
  //     }
  //     this.featureDataService.setUserStoryGenerated(this.userstorygenerated);
  //     this.errorMessage = null;
  //   }
  // }



  generateuserstory(): void {
    this.isLoading = true; // Show loader
    this.userid = null;
    this.userstorypayload = `Summary:${this.summary},Description:${this.description},tasks:${this.stepsIdentification},userid:${this.userid},epicid:${this.featureID}`;
    this.featureService
      .sendUserStoryGenerator(this.userstorypayload)
      .pipe(timeout(180000)) // 180000 milliseconds = 180 seconds
      .subscribe(
        (response) => {
          //console.log("Generate user story", response);

          this.isLoading = false; // Hide loader
          if (response && Array.isArray(response)) {
            // Print all user stories
            // this.userstorygenerated = response[0];

            this.userstorygenerated = response[0]["User_Story"].content;
            //console.log("User Stories:", this.userstorygenerated);

            // Parse the object at index 1
            const storiesObject = JSON.parse(response[1]);

            console.log(response[1])
            if (storiesObject) {
              this.formatData(response[1])

              console.log(this.duplicateuserstoryData)
              console.log(this.newuserstory)
            } else {
              console.error('The structure of the second item in the array is not as expected:', storiesObject);
            }

            this.featureDataService.setUserStoryGenerated(this.userstorygenerated);
            this.errorMessage = null;
          }
        },
        (error: HttpErrorResponse) => {
          this.isLoading = false; // Hide loader
          console.error('Error sending feature description:', error);
          this.errorMessage = 'Error sending feature description';
        }
      );
  }
   formatStories = (stories: string[]) => {
    console.log(stories)
    return stories.join(' ').replace(/, /g, ',');

  };
  formatData(inputData: any) {
    const data = JSON.parse(inputData);
    // Function to format stories
    // Construct the desired output
    const output = {
      Duplicated_Stories: [
        this.formatStories(data.Duplicated_Stories)
      ],
      New_Stories: [
        this.formatStories(data.New_Stories) // Adjust the filter logic as needed
      ]
    };
    console.log(output)
    let duplicateStories: any = []
    output.Duplicated_Stories.forEach((data: any, i) => {
      duplicateStories.push(...data.split('. User Story'))
    })
    duplicateStories.shift()
   this.duplicateuserstory =[]
    duplicateStories.forEach((ele: any) => {
      ele = 'User Story' + ele;
      this.duplicateuserstory.push(ele)
    })
    console.log(this.duplicateuserstory)
    let newStories: any = []
    output.New_Stories.forEach((data: any, i: any) => {
      newStories.push(...data.split('. User Story'))
    })
    console.log(newStories)
    //newStories.shift()
    this.newuserstory = [];
    newStories.forEach((ele: any) => {
      ele = 'User Story' + ele;
      this.newuserstory.push(ele)
    })
    console.log( this.newuserstory)
  }
  duplicateuserstorybtn(): void {
    // this.duplicateuserstory.forEach((text: any) => {
    //   text.split(("User Story:"))
    //   console.log(text)
    // });
    // this.newuserstory.forEach((text: any) => {
    //   text.split(("User Story:"))
    //   console.log(text)

    // });
    if(this.duplicateuserstory?.length || this.newuserstory?.length){
      this.showModal = true;
    }else{
      this.errorMessage = 'Could not find the user stories'
    }
    console.log(this.showModal)

  }
  closeModel(){
   
    this.showModal = false;
  }

  next(): void {
    if (this.userstorygenerated) {
      this.router.navigate(['/feature/pushtojira']);
      this.featureDataService.setUserStoryGenerated(this.userstorygenerated);
    } else {
      this.errorMessage =
        'Could not find the details, please fetch details to proceed next.';
    }
  }

  previous(): void {
    this.router.navigate(['/feature/stepsidentification']);
  }
}