import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FeatureService } from '../services/feature.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FeatureDataService } from '../services/feature-data.service';
import { timeout } from 'rxjs/operators'; 
@Component({
  selector: 'app-steps-identification',
  templateUrl: './steps-identification.component.html',
  styleUrls: ['./steps-identification.component.css'],
})
export class StepsIdentificationComponent {
  errorMessage: string | null = null;
  description: string = '';
  summary: string = '';
  stepsIdentification: string = '';
  rewriteresponse: string = '';
  isLoading: boolean = false; // Property to control the loader

  constructor(
    private router: Router,
    private featureService: FeatureService,
    private featureDataService: FeatureDataService
  ) {}

  ngOnInit(): void {
    this.description = this.featureDataService.getDescription();
    this.summary = this.featureDataService.getSummary();
    this.stepsIdentification = this.featureDataService.getStepsIdentification();
    
    // if (!this.stepsIdentification) {
    //   this.rewritefeature();
    // }
  }
 
  rewritefeature(): void {
    this.featureService
      .sendRewriteFeatureDescription(this.description, this.summary)
      .subscribe(
        (response) => {
          if (response) {
            this.rewriteresponse = response;
            console.log('Feature Rewrite:', response);
            // this.featureDataService.setFeatureData(
            //   this.featureDataService.getFeatureId()!,
            //   this.rewriteresponse,
            //   this.summary
            // );
          } else {
            console.error('Invalid response structure', response);
            this.errorMessage = 'Invalid response structure';
          }
        },
        (error: HttpErrorResponse) => {
          console.error('Error sending feature description:', error);
          this.errorMessage = 'Error sending feature description';
        }
      );
  }

  identifysteps(): void {
    this.isLoading = true; // Show loader
    const stepspayload = this.description + this.summary
    console.log(stepspayload);
    this.featureService.sendStepsIdentification(stepspayload)
    .pipe(timeout(180000)) // 180000 milliseconds = 180 seconds
    .subscribe(
      (response) => {
        this.isLoading = false; // Hide loader
        if (response) {
          console.log('Steps Identification:', response);
          this.stepsIdentification = response;
          this.errorMessage = null;
          this.featureDataService.setStepsIdentification(
            this.stepsIdentification
          );
        } else {
          console.error('Invalid response structure', response);
          this.errorMessage = 'Invalid response structure';
        }
      },
      (error: HttpErrorResponse) => {
        this.isLoading = false; // Hide loader
        console.error('Error sending feature description:', error);
        this.errorMessage = 'Error sending feature description';
      }
    );
  }

  next(): void {
    if (this.stepsIdentification) {
      this.router.navigate(['/feature/userstorygeneration']);
      this.featureDataService.setStepsIdentification(
        this.stepsIdentification
      );
    } else {
      this.errorMessage =
        'Could not find the details, please fetch details to proceed next.';
    }
  }

  previous() {
    this.router.navigate(['/feature/featurerewrite']);
  }
}
