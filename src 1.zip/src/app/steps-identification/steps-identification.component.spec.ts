import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepsIdentificationComponent } from './steps-identification.component';

describe('StepsIdentificationComponent', () => {
  let component: StepsIdentificationComponent;
  let fixture: ComponentFixture<StepsIdentificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StepsIdentificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StepsIdentificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
