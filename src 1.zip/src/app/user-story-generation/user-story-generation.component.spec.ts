import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserStoryGenerationComponent } from './user-story-generation.component';

describe('UserStoryGenerationComponent', () => {
  let component: UserStoryGenerationComponent;
  let fixture: ComponentFixture<UserStoryGenerationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserStoryGenerationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserStoryGenerationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
