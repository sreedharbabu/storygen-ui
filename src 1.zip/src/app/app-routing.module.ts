import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeatureIdComponent } from './feature-id/feature-id.component';
import { IntroductionComponent } from './introduction/introduction.component';
import { FeatureAnalysisComponent } from './feature-analysis/feature-analysis.component';
import { FeatureRewriteComponent } from './feature-rewrite/feature-rewrite.component';
import { StepsIdentificationComponent } from './steps-identification/steps-identification.component';
import { UserStoryGenerationComponent } from './user-story-generation/user-story-generation.component';
import { PushToJiraComponent } from './push-to-jira/push-to-jira.component';
import { CatalogComponent } from './catalog/catalog.component';
import { InProgressComponent } from './in-progress/in-progress.component';
import { FeatureRequirementsComponent } from './feature-requirements/feature-requirements.component';

// const routes: Routes = [
//   // { path: '', redirectTo: '/introduction', pathMatch: 'full' },  // default route
//   { path: '', redirectTo: '/catalog', pathMatch: 'full' },  // default route
//   { path: 'catalog', component: CatalogComponent }, 
//   { path: 'in-progress', component: InProgressComponent },
//   // { path: 'feature-require', component: FeatureRequirementsComponent },

//  // { path: '', redirectTo: '/introduction', pathMatch: 'full' },  // default route
//   { path: 'introduction', component: IntroductionComponent }, //step1
//   { path: 'featuredetails', component: FeatureIdComponent }, //step2
//   { path: 'featureanalysis/:featureId', component: FeatureAnalysisComponent }, //step3
//   { path: 'featurerewrite', component: FeatureRewriteComponent }, //step4
//   { path: 'stepsidentification', component: StepsIdentificationComponent }, //step5
//   { path: 'userstorygeneration', component: UserStoryGenerationComponent }, //step6
//   { path: 'pushtojira', component: PushToJiraComponent }, //step7
// ];



const
    routes:
    Routes = [{
            path: '',
            redirectTo: '/catalog',
            pathMatch: 'full'
        },
        // default route
        {
            path: 'catalog',
            component: CatalogComponent
        }, {
            path: 'in-progress',
            component: InProgressComponent
        }, {
            path: 'feature',
            component: FeatureRequirementsComponent,
            children: [{
                    path: '',
                    redirectTo: 'introduction',
                    pathMatch: 'full'
                },
                // default nested route
                {
                    path: 'introduction',
                    component: IntroductionComponent
                },
                // step1
                {
                    path: 'featuredetails',
                    component: FeatureIdComponent
                },
                // step2
                {
                    path: 'featureanalysis/:featureId',
                    component: FeatureAnalysisComponent
                },
                // step3
                {
                    path: 'featurerewrite',
                    component: FeatureRewriteComponent
                },
                // step4
                {
                    path: 'stepsidentification',
                    component: StepsIdentificationComponent
                },
                // step5
                {
                    path: 'userstorygeneration',
                    component: UserStoryGenerationComponent
                },
                // step6
                {
                    path: 'pushtojira',
                    component: PushToJiraComponent
                },
                // step7
            ]
        }
    ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
