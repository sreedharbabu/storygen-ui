import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeatureAnalysisComponent } from './feature-analysis.component';

describe('FeatureAnalysisComponent', () => {
  let component: FeatureAnalysisComponent;
  let fixture: ComponentFixture<FeatureAnalysisComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeatureAnalysisComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FeatureAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
