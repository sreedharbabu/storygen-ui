import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FeatureService } from '../services/feature.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FeatureDataService } from '../services/feature-data.service';
import { timeout } from 'rxjs/operators';
@Component({
  selector: 'app-feature-analysis',
  templateUrl: './feature-analysis.component.html',
  styleUrls: ['./feature-analysis.component.css'],
})
export class FeatureAnalysisComponent {
  featureId: string | null = null;
  errorMessage: string | null = null;
  description: string = '';
  summary: string = '';
  key: string = '';
  analysisfeedback: string = '';
  role: string = '';
  isLoading: boolean = false; // Property to control the loader

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private featureService: FeatureService,
    private featureDataService: FeatureDataService
  ) {}

  ngOnInit(): void {
    this.featureId = this.route.snapshot.paramMap.get('featureId');
    this.description = this.featureDataService.getDescription();
    this.summary = this.featureDataService.getSummary();
    this.analysisfeedback = this.featureDataService.getAnalysisFeedback();

    console.log('feature analysis oninit:', this.featureId);
    // if (this.featureId && (!this.description || !this.summary)) {
    //   this.fetchFeatureDescription(this.featureId);
    // } else {
    //   this.errorMessage = 'Feature ID is missing';
    // }
  }

  // No need to call api again as we are fetching data from previous session
  fetchFeatureDescription(featureID: string): void {
    this.featureService
      .getFeatureDescription(featureID)
      .pipe(timeout(180000)) // 180000 milliseconds = 180 seconds
      .subscribe(
        (response) => {
          // Check if the response has issues and fields to prevent undefined errors
          if (
            response &&
            response.issues &&
            response.issues.length > 0 &&
            response.issues[0].fields
          ) {
            const fields = response.issues[0].fields;
            const description = fields.description;
            const summary = fields.summary;
            this.description = description;
            this.summary = summary;
            this.key = response.issues[0].key;
            console.log('Feature description:', description);
            console.log('Feature summary:', summary);
            this.featureDataService.setFeatureData(
              this.featureId!,
              this.description,
              this.summary
            );
          } else {
            console.error('Invalid response structure', response);
            this.errorMessage = 'Invalid response structure';
          }
        },
        (error: HttpErrorResponse) => {
          console.error('Error fetching feature description:', error);
          this.errorMessage = 'Error fetching feature description';
        }
      );
  }

  analyzeFeature(): void {
    this.isLoading = true; // Show loader
    this.featureService
      .sendFeatureDescription(this.description, this.summary)
      .pipe(timeout(180000)) // 180000 milliseconds = 180 seconds
      .subscribe(
        (response) => {
          this.isLoading = false; // Hide loader
          if (response && this.description && this.summary) {
            this.analysisfeedback = response;
            console.log('Feature Analysis:', this.analysisfeedback);
            this.featureDataService.setAnalysisFeedback(this.analysisfeedback);
            console.log("setAnalysisFeedback in analysis", this.analysisfeedback)
          } else {
            console.error('Invalid response structure', response);
            this.errorMessage = 'Invalid response structure';
          }
        },
        (error: HttpErrorResponse) => {
          this.isLoading = false; // Hide loader
          console.error('Error sending feature description:', error);
          this.errorMessage = 'Error sending feature description';
        }
      );
  }

  next(): void {
    if (this.featureId && this.description && this.summary) {
      this.featureDataService.setFeatureData(
        this.featureId!,
        this.description,
        this.summary
      );
      this.router.navigate(['/feature/featurerewrite']);
    }
  }

  previous() {
    this.router.navigate(['/feature/featuredetails']);
  }
}
