import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DuplicateStoriesModalComponent } from './duplicate-stories-modal.component';

describe('DuplicateStoriesModalComponent', () => {
  let component: DuplicateStoriesModalComponent;
  let fixture: ComponentFixture<DuplicateStoriesModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DuplicateStoriesModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DuplicateStoriesModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
