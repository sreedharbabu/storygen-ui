import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeatureRequirementsComponent } from './feature-requirements.component';

describe('FeatureRequirementsComponent', () => {
  let component: FeatureRequirementsComponent;
  let fixture: ComponentFixture<FeatureRequirementsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeatureRequirementsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FeatureRequirementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
