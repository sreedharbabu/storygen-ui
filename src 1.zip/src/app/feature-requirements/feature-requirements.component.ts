import { Component } from '@angular/core';

@Component({
  selector: 'app-feature-requirements',
  templateUrl: './feature-requirements.component.html',
  styleUrls: ['./feature-requirements.component.css']
})
export class FeatureRequirementsComponent {
  
}
