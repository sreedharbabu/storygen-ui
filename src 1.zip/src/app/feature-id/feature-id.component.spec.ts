import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeatureIdComponent } from './feature-id.component';

describe('FeatureIdComponent', () => {
  let component: FeatureIdComponent;
  let fixture: ComponentFixture<FeatureIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeatureIdComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FeatureIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
