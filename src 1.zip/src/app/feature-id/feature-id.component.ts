import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FeatureService } from '../services/feature.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FeatureDataService } from '../services/feature-data.service';
import { timeout } from 'rxjs/operators'; 
@Component({
  selector: 'app-feature-id',
  templateUrl: './feature-id.component.html',
  styleUrls: ['./feature-id.component.css'],
})
export class FeatureIdComponent {
  featureId: string = '';
  errorMessage: string | null = null;
  description: string | null = null;
  summary: string | null = null;
  key: string = '';
  isLoading: boolean = false; // Property to control the loader
  constructor(
    private router: Router,
    private featureService: FeatureService,
    private featureDataService: FeatureDataService
  ) {}

  ngOnInit(): void {
    this.featureId = this.featureDataService.getFeatureId() || '';
  }

  // showing feature id and description in same screen
  fetchDetails(): void {
    if (!this.featureId) {
      this.errorMessage =
        'Could not find the details, please check the feature ID provided.';
      this.summary = null;
      this.description = null;
      return;
    }
    console.log('feature id On click of fetch Details:', this.featureId);
    this.isLoading = true; // Show loader
    this.featureService.getFeatureDescription(this.featureId)
    .pipe(timeout(180000)) // 180000 milliseconds = 180 seconds
    .subscribe(
      (response) => {
        this.isLoading = false; // Hide loader
        // Check if the response has issues and fields to prevent undefined errors
        if (
          response &&
          response.issues &&
          response.issues.length > 0 &&
          response.issues[0].fields
        ) {
          const fields = response.issues[0].fields;
          const description = fields.description;
          const summary = fields.summary;
          this.description = description;
          this.summary = summary;
          this.key = response.issues[0].key;
          console.log('Feature Id:', this.key);
          console.log('Feature summary:', summary);
          console.log('Feature description:', description);
          this.errorMessage = null;
        } else {
          console.error('Invalid response structure', response);
          this.errorMessage =
            'Could not find the details, please check the feature ID provided.';
        }
      },
      (error: HttpErrorResponse) => {
        this.isLoading = false; // Hide loader
        console.error('Error fetching feature description:', error);
        this.errorMessage = 'Error fetching feature details';
      }
    );
  }

  next(): void {
    if (this.featureId && this.description && this.summary) {
      this.featureDataService.setFeatureId(this.featureId);
      this.featureDataService.setFeatureData(
        this.featureId!,
        this.description,
        this.summary
      );
      this.router.navigate(['/feature/featureanalysis', this.featureId]);
    } else {
      this.errorMessage =
        'Could not find the details, please fetch details to proceed next.';
    }
  }

  previous() {
    this.router.navigate(['/feature/introduction']);
  }
}
