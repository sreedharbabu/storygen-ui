import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';

import { AppComponent } from './app.component';
import { FeatureRequirementsComponent } from './feature-requirements/feature-requirements.component';
import { IntroductionComponent } from './introduction/introduction.component';
import { FeatureIdComponent } from './feature-id/feature-id.component';
import { FeatureAnalysisComponent } from './feature-analysis/feature-analysis.component';
import { FeatureRewriteComponent } from './feature-rewrite/feature-rewrite.component';
import { StepsIdentificationComponent } from './steps-identification/steps-identification.component';
import { UserStoryGenerationComponent } from './user-story-generation/user-story-generation.component';
import { PushToJiraComponent } from './push-to-jira/push-to-jira.component';
import { CatalogComponent } from './catalog/catalog.component';
import { InProgressComponent } from './in-progress/in-progress.component';

 
// import { FeatureDescriptionComponent } from './feature-description/feature-description.component';
// import { FeatureDetailsComponent } from './feature-details/feature-details.component';
import { FeatureDataService } from './services/feature-data.service';
import { SuccessDialogComponent } from './success-dialog/success-dialog.component';
import { DuplicateStoriesModalComponent } from './duplicate-stories-modal/duplicate-stories-modal.component';


@NgModule({
  declarations: [
    AppComponent,
    FeatureRequirementsComponent,
    IntroductionComponent,
    FeatureIdComponent,
    // FeatureDescriptionComponent,
    // FeatureDetailsComponent,
    FeatureAnalysisComponent,
    FeatureRewriteComponent,
    StepsIdentificationComponent,
    UserStoryGenerationComponent,
    PushToJiraComponent,
    SuccessDialogComponent,
    CatalogComponent,
    InProgressComponent,
    DuplicateStoriesModalComponent,
  ],
  imports: [BrowserModule, AppRoutingModule, FormsModule, HttpClientModule,MatDialogModule,MatCardModule, MatGridListModule, BrowserAnimationsModule],
  providers: [FeatureDataService],
  bootstrap: [AppComponent],
})
export class AppModule {}
