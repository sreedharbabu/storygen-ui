import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FeatureService } from '../services/feature.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FeatureDataService } from '../services/feature-data.service';
import { timeout } from 'rxjs/operators';
// import * as $ from 'jquery';
import { SuccessDialogComponent } from '../success-dialog/success-dialog.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-push-to-jira',
  templateUrl: './push-to-jira.component.html',
  styleUrls: ['./push-to-jira.component.css'],
})
export class PushToJiraComponent {
  errorMessage: string | null = null;
  jirafeatureId: string = '';
  userstorygenerated: any[] = [];
  successMessage: string = ''; // Property to store the success message
  isLoading: boolean = false; // Property to control the loader
  selectedNewStories: any ;
  selectedDuplicateStories:any;

  constructor(
    private router: Router,
    private featureService: FeatureService,
    private featureDataService: FeatureDataService,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    // this.userstorygenerated = this.featureDataService.getUserStoryGenerated();
    
    this.selectedNewStories = this.featureDataService.getSelectedNewStories();
    this.selectedDuplicateStories = this.featureDataService.getSelectedDuplicateStories();
    console.log(this.selectedNewStories)
    console.log(this.selectedDuplicateStories)
    this.userstorygenerated = [...this.selectedNewStories,...this.selectedDuplicateStories]
    // this.userstorygenerated = stories.join('\n');

  }

  pushtojira(): void {
    let payload = {
      summary: this.userstorygenerated,
      epicid:this.featureDataService.getFeatureId()
    }
    // this.userstorygenerated = this.userstorygenerated + ',epicid:'+this.featureDataService.getFeatureId();
    this.isLoading = true; // Show loader
    this.featureService
      .sendPushtojira(payload)
      .pipe(timeout(180000)) // 180000 milliseconds = 180 seconds
      .subscribe(
        (response) => {
          this.isLoading = false; // Hide loader
          if (response) {
            console.log('Push to jira:', response);
            // Parse the JSON string response
            const parsedResponse = JSON.parse(response);
            this.successMessage = this.formatSuccessMessage(parsedResponse);
            this.dialog.open(SuccessDialogComponent, {
              data: { successMessage: this.successMessage },
            });
            console.log(this.successMessage);
          } else {
            console.error('Invalid response structure', response);
            this.errorMessage = 'Invalid response structure';
          }
        },
        (error: HttpErrorResponse) => {
          this.isLoading = false; // Hide loader
          console.error('Error sending feature description:', error);
          this.errorMessage = 'Error sending feature description';
        }
      );
  }

  formatSuccessMessage(response: any): string {
    let message =
      'The following user stories were successfully pushed to Jira for below feature id:\n\n';
    for (const [key, value] of Object.entries(response)) {
      message += `${key}: ${value}\n`;
    }
    return message;
  }

  previous() {
    this.router.navigate(['/feature/userstorygeneration']);
  }
}
