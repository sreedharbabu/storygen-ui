import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PushToJiraComponent } from './push-to-jira.component';

describe('PushToJiraComponent', () => {
  let component: PushToJiraComponent;
  let fixture: ComponentFixture<PushToJiraComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PushToJiraComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PushToJiraComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
