import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-catalog',
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.css'],
})
export class CatalogComponent {
  cards = [
    {
      title: 'Stability/Scalability',
      content: '',
      route: '/in-progress'
    },
    {
      title: 'Security',
      content: '',
      route: '/in-progress'
    },
    {
      title: 'Compliance',
      content: '',
      route: '/in-progress'
    },
    {
      title: 'Tech Debt',
      content: '',
      route: '/feature/featuredetails'
    },
    {
      title: 'Build/Enhancements',
      content: '',
      route: '/in-progress'
    },
  ];

  constructor(private router: Router) {}

  onCardClick(route: any) {
    this.router.navigate([route]);
  }
}
