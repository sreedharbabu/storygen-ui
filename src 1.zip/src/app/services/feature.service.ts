import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, map } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class FeatureService {
  // GET API URL to fetch description
  // private apiUrl = 'https://advantagealm.atlassian.net/rest/api/latest/search?jql=issue=TGP-1';

  private jiraapiUrl = '/rest/api/latest/search';
  private analysisapiUrl = '/api/get_prompt_feature_analyze';
  private rewriteapiUrl = '/api/get_prompt_feature_rewrite';
  private stepsidentaificationpiUrl = '/api/get_prompt_feature_stepidentify';
  private userstorygenerationapiUrl = '/api/get_prompt_feature_userstory';
  private pushtojiraapiUrl = '/api/get_prompt_feature_jirapush';

  constructor(private http: HttpClient) {}

  // get feature description and summary for JIRA api
  getFeatureDescription(issue: string): Observable<any> {
    const url = `${this.jiraapiUrl}?jql=issue=${issue}`;
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization:
        'Basic ' +
        btoa(
          'sruthiv@hcltech.com:ATATT3xFfGF0RsQ0V1dYM9P9IRFUBaVv3cp1SvBFayGcm9bTVWjIdrNQSMfJYTQTkgIKxbsEr_6knzvtVgVenMF9EMhClZUOBnCBYEyvuDXpuxHCA8ATECsUbPjGETz4ZzHW95AgRJFzd-08yNg63tP8-oAw-1if6nRGJQa90h2KsdeY8XvWXeg=63B65EE3'
        ),
    });
    return this.http.get<any>(url, { headers });
  }

  // send feature description and summary for feature analysis response
  sendFeatureDescription(
    description: string,
    summary: string
  ): Observable<any> {
    const payload = { description: description, summary: summary, userid: null };
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    console.log(payload);
    return this.http.post<any>(this.analysisapiUrl, payload, { headers });
  }

  // send feature description and summary for feature rewrite response
  sendRewriteFeatureDescription(
    description: string,
    summary: string
  ): Observable<any> {
    const payload = { description: description, summary: summary, userid: null };
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    console.log(payload);
    return this.http.post<any>(this.rewriteapiUrl, payload, { headers });
  }

  // payload summary: "description+summary" for steps identification response
  sendStepsIdentification(
    summary: string // description+summary send as payload
  ): Observable<any> {
    const payload = { summary: summary, userid: null };
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    console.log(payload);
    return this.http.post<any>(this.stepsidentaificationpiUrl, payload, {
      headers,
    });
  }

  // payload summary: "Summary:,Description:,tasks:" for user story generation response
  sendUserStoryGenerator(
    summary: string //"Summary:,Description:,tasks:,userid:" send as payload
  ): Observable<any> {
    const payload = { summary: summary };
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    console.log("service class", payload);
    // return this.http.post<any>(this.userstorygenerationapiUrl, payload, {
    //   headers,
    // });

    const response = this.http.post<any>(this.userstorygenerationapiUrl, payload, {
      headers,
    });
    console.log("user story response from service", response);
    return response
  }

  // sendUserStoryGenerator(
  //   description: string,
  //   summary: string,
  //   tasks: string
  // ): Observable<any> {
  //   const payloadSummary = `Summary:${summary},Description:${description},tasks:${tasks}`;
  //   const payload = { summary: payloadSummary };
  //   const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  //   console.log(payload);
  //   return this.http.post<any>(this.userstorygenerationapiUrl, payload, {
  //     headers,
  //   });
  // }

  // send user story generation response for getting response for push to jira screen
  sendPushtojira(
    reqObj: any
    //user story generation response send as payload
  ): Observable<any> {
    const payload = reqObj;
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    console.log(payload);
    return this.http.post<any>(this.pushtojiraapiUrl, payload, { headers });
  }
}
