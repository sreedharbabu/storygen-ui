import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class FeatureDataService {
  private featureId: string | null = null;
  private description: string = '';
  private summary: string = '';
  private rewritedescription: string = '';
  private analysisfeedback: string = '';
  private stepsIdentification: string = '';
  private userstorygenerated: string = '';
  private selectedNewStories: string[] = [];
  private selectedDuplicateStories:string[]=[];
  
  setFeatureData(featureId: string, description: string, summary: string) {
    this.featureId = featureId;
    this.description = description;
    this.summary = summary;
  }

  setFeatureId(featureId: string) {
    this.featureId = featureId;
  }

  getFeatureId(): string | null {
    return this.featureId;
  }

  setDescription(description: string): void {
    this.description = description;
  }

  getDescription(): string {
    return this.description;
  }  

  setSummary(summary: string): void {
    this.summary = summary;
  }

  getSummary(): string {
    return this.summary;
  }

  setAnalysisFeedback(analysisfeedback: string) {
    this.analysisfeedback = analysisfeedback;
  }

  getAnalysisFeedback(): string {
    return this.analysisfeedback;
  }

  setRewriteDescription(rewritedescription: string) {
    this.rewritedescription = rewritedescription;
  }

  getRewriteDescription(): string {
    return this.rewritedescription;
  }

  setStepsIdentification(stepsIdentification: string) {
    this.stepsIdentification = stepsIdentification;
  }

  getStepsIdentification(): string {
    return this.stepsIdentification;
  }

  setUserStoryGenerated(userstorygenerated: string) {
    this.userstorygenerated = userstorygenerated;
  }

  getUserStoryGenerated(): string {
    return this.userstorygenerated;
  }

  setSelectedNewStories(stories: string[]) {
    this.selectedNewStories = stories;
  }

  getSelectedNewStories(): string[] {
    return this.selectedNewStories;
  }
  
  setSelectedDuplicateStories(stories: string[]) {
    this.selectedDuplicateStories = stories;
  }

  getSelectedDuplicateStories(): string[] {
    return this.selectedDuplicateStories;
  }
}
