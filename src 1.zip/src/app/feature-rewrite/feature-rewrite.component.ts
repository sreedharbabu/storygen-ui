import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FeatureService } from '../services/feature.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FeatureDataService } from '../services/feature-data.service';
import { timeout } from 'rxjs/operators'; 
@Component({
  selector: 'app-feature-rewrite',
  templateUrl: './feature-rewrite.component.html',
  styleUrls: ['./feature-rewrite.component.css'],
})
export class FeatureRewriteComponent {
  featureId: string | null = null;
  errorMessage: string | null = null;
  description: string = '';
  summary: string = '';
  key: string = '';
  isLoading: boolean = false; // Property to control the loader
  rewritedescription: string = '';

  constructor(
    private router: Router,
    private featureService: FeatureService,
    private featureDataService: FeatureDataService
  ) {}

  ngOnInit(): void {
    this.featureId = this.featureDataService.getFeatureId();
    this.description = this.featureDataService.getDescription();
    this.summary = this.featureDataService.getSummary();
    this.rewritedescription = this.featureDataService.getRewriteDescription();
   

    // If featureId is present but description or summary is missing, fetch from API
    // if (this.featureId && (!this.description || !this.summary)) {
    //   this.fetchFeatureDescription(this.featureId);
    // } else {
    //   this.errorMessage = 'Feature ID is missing';
    // }
  }

  fetchFeatureDescription(featureID: string): void {
    this.featureService.getFeatureDescription(featureID)
    .pipe(timeout(180000)) // 180000 milliseconds = 180 seconds
    .subscribe(
      (response) => {
        // Check if the response has issues and fields to prevent undefined errors
        if (
          response &&
          response.issues &&
          response.issues.length > 0 &&
          response.issues[0].fields
        ) {
          const fields = response.issues[0].fields;
          const description = fields.description;
          const summary = fields.summary;
          this.description = description;
          this.summary = summary;
          this.key = response.issues[0].key;
          console.log('Feature description:', description);
          console.log('Feature summary:', summary);
          this.featureDataService.setFeatureData(
            this.featureId!,
            this.description,
            this.summary
          );
        } else {
          console.error('Invalid response structure', response);
          this.errorMessage = 'Invalid response structure';
        }
      },
      (error: HttpErrorResponse) => {
        console.error('Error fetching feature description:', error);
        this.errorMessage = 'Error fetching feature description';
      }
    );
  }

  rewritefeature(): void {
    this.isLoading = true; // Show loader
    this.featureService
      .sendRewriteFeatureDescription(this.description, this.summary)
      .pipe(timeout(180000)) // 180000 milliseconds = 180 seconds
      .subscribe(
        (response) => {
          this.isLoading = false; // Hide loader
          if (response) {
            this.description = response;
            console.log('Feature Rewrite:', this.description);
            // this.featureDataService.setFeatureData(
            //   this.featureId!,
            //   this.featureDataService.getDescription(),
            //   this.summary
            // );
            this.featureDataService.setRewriteDescription(this.description);
          } else {
            console.error('Invalid response structure', response);
            this.errorMessage = 'Invalid response structure';
          }
        },
        (error: HttpErrorResponse) => {
          this.isLoading = false; // Hide loader
          console.error('Error sending feature description:', error);
          this.errorMessage = 'Error sending feature description';
        }
      );
  }

  next(): void {
    this.router.navigate(['/feature/stepsidentification']);
  }

  previous() {
    if (this.featureId) {
      this.router.navigate(['/feature/featureanalysis', this.featureId]);
    } else {
      this.errorMessage = 'Feature ID is missing';
    }
  }
}
