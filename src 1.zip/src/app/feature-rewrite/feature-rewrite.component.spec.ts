import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeatureRewriteComponent } from './feature-rewrite.component';

describe('FeatureRewriteComponent', () => {
  let component: FeatureRewriteComponent;
  let fixture: ComponentFixture<FeatureRewriteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeatureRewriteComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FeatureRewriteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
